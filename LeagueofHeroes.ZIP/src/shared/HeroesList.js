const heroesList = [
    {
        id: 1,
        image: '',
        name: 'Homem de Ferro',
        super_power: '',
    },
    {
        id: 2,
        image: '',
        name: 'Super Homem',
        super_power: '',
    },
    {
        id: 3,
        image: '',
        name: 'Wolverine',
        super_power: '',
    },
    {
        id: 4,
        image: '',
        name: 'San Goku',
        super_power: '',
    },
    {
        id: 5,
        image: '',
        name: 'Homem Formiga',
        super_power: '',
    },
    {
        id: 6,
        image: '',
        name: 'Super Girl',
        super_power: '',
    },
]
export default heroesList   